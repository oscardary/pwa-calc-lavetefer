import { useEffect, useState } from "react";
import { supabase } from "@/lib/auth/supabaseClient";

export default function DebugAuth() {
  const [sessionJson, setSessionJson] = useState("cargando...");
  const [events, setEvents] = useState<string[]>([]);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data, error }) => {
      if (!mounted) return;
      setSessionJson(JSON.stringify({ session: data?.session, error }, null, 2));
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      setEvents((prev) => [
        `[${new Date().toISOString()}] ${event} - user: ${session?.user?.email ?? "null"}`,
        ...prev,
      ]);
      setSessionJson(JSON.stringify({ session }, null, 2));
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return (
    <div style={{ padding: 24, fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas" }}>
      <h1>Debug Supabase Auth</h1>
      <p>Estado de sesión actual:</p>
      <pre style={{ background: "#f6f8fa", padding: 12, borderRadius: 8 }}>{sessionJson}</pre>
      <h2>Eventos</h2>
      <ul>
        {events.map((e, i) => <li key={i}>{e}</li>)}
      </ul>
      <hr />
      <button onClick={() => supabase.auth.signOut()}>Sign Out</button>
    </div>
  );
}
