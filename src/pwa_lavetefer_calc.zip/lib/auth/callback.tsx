import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "./supabaseClient";

export default function CallbackPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Obtiene la sesión actual (si ya está autenticado)
        const { data, error } = await supabase.auth.getSession();

        if (error) {
          setErrorMsg("No pudimos iniciar tu sesión. Intenta nuevamente.");
          console.error("Error obteniendo sesión:", error.message);
          setLoading(false);
          return;
        }

        // Si NO hay sesión, probablemente es un login mágico → Supabase la crea automáticamente
        if (!data.session) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(window.location.href);

          if (exchangeError) {
            setErrorMsg("Error al confirmar tu correo. Intenta registrarte de nuevo.");
            console.error("Error intercambiando código:", exchangeError.message);
            setLoading(false);
            return;
          }
        }

        // Redirige al dashboard
        navigate("/dashboard");
      } catch (err) {
        console.error(err);
        setErrorMsg("Ha ocurrido un error inesperado.");
      } finally {
        setLoading(false);
      }
    };

    handleCallback();
  }, [navigate]);

  return (
    <div className="flex items-center justify-center h-screen bg-gray-50">
      <div className="p-8 bg-white rounded-2xl shadow-lg max-w-md w-full text-center">
        {loading && (
          <>
            <h1 className="text-xl font-bold mb-4">Validando tu sesión...</h1>
            <p className="text-gray-600">Por favor espera unos segundos</p>
          </>
        )}

        {!loading && errorMsg && (
          <>
            <h1 className="text-xl font-bold text-red-600 mb-4">¡Ups!</h1>
            <p className="text-gray-600">{errorMsg}</p>
            <button
              onClick={() => navigate("/login")}
              className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Volver al login
            </button>
          </>
        )}
      </div>
    </div>
  );
}
