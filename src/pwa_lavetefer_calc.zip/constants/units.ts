
export const UNIDADES_CONCENTRACION = ['mg/ml', 'mcg/ml', 'g/ml', 'UI/ml']
export const UNIDADES_POSOLOGIA = ['mg/kg', 'mcg/kg', 'g/kg', 'UI/kg']
